if (typeof jQuery.noConflict() == 'function'){
	jQuery.noConflict();
}