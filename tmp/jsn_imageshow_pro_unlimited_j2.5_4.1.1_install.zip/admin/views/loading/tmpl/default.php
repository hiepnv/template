<?php
/**
 * @author JoomlaShine.com Team
 * @copyright JoomlaShine.com
 * @link joomlashine.com
 * @package JSN ImageShow
 * @version $Id: default.php 6505 2011-05-31 11:01:31Z trungnq $
 * @license GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die( 'Restricted access' );

?>
<link rel="stylesheet" href="<?php echo JURI::root(true).'/administrator/components/com_imageshow/assets/css/imageshow.css';?>" type="text/css" />
<div class="jsn-loading-bg"></div>
<?php exit();?>